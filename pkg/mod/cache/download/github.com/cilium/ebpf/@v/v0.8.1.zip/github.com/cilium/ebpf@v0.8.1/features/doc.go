// Package features allows probing for BPF features available to the calling process.
package features
